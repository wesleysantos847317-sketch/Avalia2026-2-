const CHAVE_PROJETO = "P26-2B-8983-AF39-E3CF-C0B3";
const recipeSeed = [
  {
    id: "salada-mediterranea",
    name: "Salada Mediterrânea",
    time: 15,
    difficulty: "Fácil",
    servings: 2,
    tags: ["leve", "veg", "rápida"],
    ingredients: [
      { qty: 150, unit: "g", item: "tomate cereja" },
      { qty: 1, unit: "unidade", item: "pepino" },
      { qty: 40, unit: "g", item: "azeitona preta" },
      { qty: 1, unit: "colher", item: "oregano" },
      { qty: 2, unit: "colheres", item: "azeite" },
      { qty: 1, unit: "unidade", item: "limão" }
    ],
    steps: [
      "Lave e corte os tomates e o pepino em pedaços uniformes.",
      "Misture em uma tigela com as azeitonas e tempere com o azeite, o limão e o oregano.",
      "Sirva imediatamente em duas porções ou conserve por até 1 dia na geladeira."
    ]
  },
  {
    id: "risoto-abobora",
    name: "Risoto de Abóbora",
    time: 40,
    difficulty: "Médio",
    servings: 4,
    tags: ["cremoso", "inverno", "principal"],
    ingredients: [
      { qty: 250, unit: "g", item: "arroz arbóreo" },
      { qty: 400, unit: "g", item: "abóbora em cubos" },
      { qty: 1, unit: "litro", item: "caldo de legumes" },
      { qty: 1, unit: "unidade", item: "cebola picada" },
      { qty: 2, unit: "colheres", item: "manteiga" },
      { qty: 80, unit: "g", item: "parmesão ralado" }
    ],
    steps: [
      "Refogue a cebola em manteiga até ficar translúcida.",
      "Adicione o arroz e mexa até absorver o sabor do refogado.",
      "Inclua a abóbora aos poucos com o caldo, mexendo até o arroz ficar cremoso.",
      "Finalize com parmesão e sirva em porções quentes."
    ]
  },
  {
    id: "tacos-frango",
    name: "Tacos de Frango com Coentro",
    time: 30,
    difficulty: "Fácil",
    servings: 3,
    tags: ["saboroso", "rápido", "familia"],
    ingredients: [
      { qty: 500, unit: "g", item: "frango desfiado" },
      { qty: 8, unit: "unidades", item: "tortilhas" },
      { qty: 1, unit: "xícara", item: "alface picada" },
      { qty: 1, unit: "xícara", item: "tomate picado" },
      { qty: 1, unit: "colher", item: "cominho" },
      { qty: 2, unit: "colheres", item: "salsa" }
    ],
    steps: [
      "Tempere o frango com cominho e cozinhe em fogo médio até ficar macio.",
      "Aqueça as tortilhas e recheie com o frango e os legumes frescos.",
      "Finalize com salsa e sirva imediatamente em porções quentes."
    ]
  }
];

const state = {
  recipes: recipeSeed,
  selectedId: recipeSeed[0].id,
  searchTerm: "",
  maxMinutes: "all",
  user: null,
  favorites: loadFavorites()
};

function getSelectedRecipe() {
  return state.recipes.find((recipe) => recipe.id === state.selectedId) || state.recipes[0];
}

function loadFavorites() {
  try {
    const stored = JSON.parse(localStorage.getItem("favoriteRecipes") || "[]");
    return Array.isArray(stored) ? stored : [];
  } catch {
    return [];
  }
}

function persistFavorites() {
  localStorage.setItem("favoriteRecipes", JSON.stringify(state.favorites));
}

async function syncFavoriteServer(recipeId, shouldAdd) {
  const userId = state.user?.userId || "manual-user";
  if (!recipeId || !userId) return;

  try {
    await fetch("/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        recipeId,
        recipeName: state.recipes.find((recipe) => recipe.id === recipeId)?.name || recipeId,
        action: shouldAdd ? "add" : "remove"
      })
    });
  } catch {
    // fallback local-only em ambientes sem deploy Cloudflare
  }
}

function formatQuantity(value) {
  if (!Number.isFinite(value)) return value;
  const rounded = Math.round(value * 100) / 100;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
}

function renderDiscordHeader() {
  const el = document.getElementById("discordUserText");
  if (!el) return;
  if (state.user) {
    const safeName = state.user.username || "Usuário do Discord";
    const safeId = state.user.userId || "local-user";
    el.textContent = `Discord: ${safeName} (${safeId})`;
    return;
  }
  el.textContent = "Entrar com Discord OAuth2";
}

function getVisibleRecipes() {
  const term = state.searchTerm.trim().toLowerCase();
  return state.recipes.filter((recipe) => {
    const matchesTerm = !term ||
      recipe.name.toLowerCase().includes(term) ||
      recipe.tags.some((tag) => tag.toLowerCase().includes(term)) ||
      recipe.ingredients.some((ingredient) => ingredient.item.toLowerCase().includes(term));

    const matchesTime = state.maxMinutes === "all" || recipe.time <= Number(state.maxMinutes);
    return matchesTerm && matchesTime;
  });
}

function renderMetrics() {
  const recipeCount = document.getElementById("metricRecipes");
  const favoriteCount = document.getElementById("metricFavorites");
  const status = document.getElementById("metricStatus");
  if (recipeCount) recipeCount.textContent = String(state.recipes.length);
  if (favoriteCount) favoriteCount.textContent = String(state.favorites.length);
  if (status) status.textContent = state.user ? "LOGADO" : "LOCAL";
}

function renderRecipeGrid() {
  const container = document.getElementById("recipeGrid");
  if (!container) return;

  const visible = getVisibleRecipes();
  if (visible.length === 0) {
    container.innerHTML = '<div class="empty-state">Nenhuma receita encontrada para os filtros atuais.</div>';
    return;
  }

  container.innerHTML = visible.map((recipe) => {
    const isActive = recipe.id === state.selectedId;
    const isFavorite = state.favorites.includes(recipe.id);
    return `
      <article class="recipe-card ${isActive ? "active" : ""}" data-id="${recipe.id}" tabindex="0">
        <div class="recipe-card-top">
          <div>
            <h3>${recipe.name}</h3>
            <div class="meta">${recipe.time} min · ${recipe.difficulty}</div>
          </div>
          <button class="favorite-button" data-favorite-id="${recipe.id}" type="button" aria-label="Favoritar receita">
            ${isFavorite ? "★" : "☆"}
          </button>
        </div>
        <div class="meta">Serve ${recipe.servings} pessoas</div>
        <div class="tag-list">
          ${recipe.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
        </div>
      </article>
    `;
  }).join("");

  container.querySelectorAll(".recipe-card").forEach((card) => {
    card.addEventListener("click", () => {
      state.selectedId = card.dataset.id;
      renderRecipeGrid();
      renderRecipeDetail();
    });
  });

  container.querySelectorAll(".favorite-button").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleFavorite(button.dataset.favoriteId);
    });
  });
}

function renderRecipeDetail() {
  const detail = document.getElementById("recipeDetail");
  if (!detail) return;
  const recipe = getSelectedRecipe();
  if (!recipe) {
    detail.innerHTML = '<p>Selecione uma receita.</p>';
    return;
  }

  const currentServings = Number(document.getElementById("portionInput")?.value || recipe.servings);
  const scale = currentServings / recipe.servings;

  detail.innerHTML = `
    <div class="detail-header">
      <h2>${recipe.name}</h2>
      <button class="favorite-button" data-favorite-id="${recipe.id}" type="button" aria-label="Favoritar receita">
        ${state.favorites.includes(recipe.id) ? "★" : "☆"}
      </button>
    </div>
    <div class="detail-meta">
      <span class="meta-pill">${recipe.time} min</span>
      <span class="meta-pill">${recipe.difficulty}</span>
      <span class="meta-pill">${recipe.tags.join(" · ")}</span>
    </div>

    <div class="portion-box">
      <label for="portionInput">Porções</label>
      <input id="portionInput" type="range" min="1" max="12" step="1" value="${currentServings}">
      <strong>${currentServings}</strong>
    </div>

    <h3>Ingredientes</h3>
    <ul class="ingredient-list">
      ${recipe.ingredients.map((item) => `
        <li>
          <span>${item.item}</span>
          <span class="qty">${formatQuantity(item.qty * scale)} ${item.unit}</span>
        </li>
      `).join("")}
    </ul>

    <h3 style="margin-top:1rem;">Modo de preparo</h3>
    <ol class="step-list">
      ${recipe.steps.map((step) => `<li>${step}</li>`).join("")}
    </ol>
  `;

  const input = document.getElementById("portionInput");
  if (input) {
    input.addEventListener("input", (event) => {
      const desired = Number(event.target.value || recipe.servings);
      state.selectedId = recipe.id;
      renderRecipeDetail();
      const summary = document.getElementById("portionInput");
      if (summary) summary.value = desired;
    });
  }

  detail.querySelector(".favorite-button")?.addEventListener("click", () => {
    toggleFavorite(recipe.id);
    renderRecipeGrid();
    renderRecipeDetail();
  });
}

function renderFavorites() {
  const container = document.getElementById("favoritesList");
  if (!container) return;

  if (state.favorites.length === 0) {
    container.innerHTML = '<div class="empty-state">Você ainda não favoritou nenhuma receita. Escolha um prato e salve na aba do livro pessoal.</div>';
    return;
  }

  const favoriteRecipes = state.recipes.filter((recipe) => state.favorites.includes(recipe.id));
  container.innerHTML = favoriteRecipes.map((recipe) => `
    <button class="favorite-item" type="button" data-favorite-name="${recipe.id}">${recipe.name}</button>
  `).join("");

  container.querySelectorAll(".favorite-item").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedId = button.dataset.favoriteName;
      renderRecipeGrid();
      renderRecipeDetail();
    });
  });
}

function toggleFavorite(id) {
  const shouldAdd = !state.favorites.includes(id);
  if (shouldAdd) {
    state.favorites.push(id);
  } else {
    state.favorites = state.favorites.filter((favoriteId) => favoriteId !== id);
  }
  persistFavorites();
  syncFavoriteServer(id, shouldAdd);
  renderMetrics();
  renderRecipeGrid();
  renderRecipeDetail();
  renderFavorites();
}

async function carregarStatus() {
  const listEl = document.getElementById("recordsList");
  if (!listEl) return;

  try {
    const res = await fetch("/api/status");
    const data = await res.json();
    listEl.innerHTML = "";

    if (data.sessionUser) {
      state.user = {
        userId: data.sessionUser.userId,
        username: data.sessionUser.username,
        avatar: data.sessionUser.avatar || "https://cdn.discordapp.com/embed/avatars/0.png"
      };
      renderDiscordHeader();
    }

    const items = Array.isArray(data.ultimosRegistros) ? data.ultimosRegistros : [];
    if (items.length === 0) {
      const li = document.createElement("li");
      li.textContent = `API online (${data.d1Connected ? "D1 conectado ✅" : "modo diagnóstico local ✅"}). Nenhum registro gravado ainda.`;
      listEl.appendChild(li);
      return;
    }

    items.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = `[${item.created_at || "agora"}] ${item.username} (${item.user_id}): ${item.conteudo}`;
      listEl.appendChild(li);
    });
  } catch {
    listEl.innerHTML = "<li>Modo estático local. Publique no Cloudflare Pages para ativar /api/status.</li>";
  }
}

document.getElementById("searchInput")?.addEventListener("input", (event) => {
  state.searchTerm = event.target.value;
  renderRecipeGrid();
});

document.getElementById("timeFilter")?.addEventListener("change", (event) => {
  state.maxMinutes = event.target.value;
  renderRecipeGrid();
});

document.getElementById("resetFiltersBtn")?.addEventListener("click", () => {
  state.searchTerm = "";
  state.maxMinutes = "all";
  const searchInput = document.getElementById("searchInput");
  const timeFilter = document.getElementById("timeFilter");
  if (searchInput) searchInput.value = "";
  if (timeFilter) timeFilter.value = "all";
  renderRecipeGrid();
});

document.getElementById("sendBtn")?.addEventListener("click", async () => {
  const input = document.getElementById("recordInput");
  const statusEl = document.getElementById("statusMessage");
  const conteudo = (input.value || "").trim();
  if (!conteudo) return;

  statusEl.textContent = "Enviando para nuvem...";
  try {
    const res = await fetch("/api/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: state.user?.userId || "manual-user",
        username: state.user?.username || "Chef Local",
        conteudo
      })
    });

    if (res.ok) {
      input.value = "";
      statusEl.textContent = "✓ Registro persistido com sucesso.";
      await carregarStatus();
    } else {
      statusEl.textContent = "Erro ao gravar no D1.";
    }
  } catch {
    statusEl.textContent = "API disponível após o deploy no Cloudflare Pages.";
  }
});

renderDiscordHeader();
renderMetrics();
renderRecipeGrid();
renderRecipeDetail();
renderFavorites();
carregarStatus();
